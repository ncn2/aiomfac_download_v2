import tkinter as tk
from IO import IO
import os





def getUserInput():
	global e2,loc,check, organicsList,toggleLDR, toggleAll,tableName
	from organicsList import organicsList
	toggleLDR = 1
	toggleAll = 1
	
	for i in range(0,len(organicsList)):
		if( organicsList[i][0] == None):
			c = i
			break
		organicsList[i][0] = organicsList[i][0].replace(",","-")
	organicsList= organicsList[0:c]
		
	
	window = tk.Tk()
	window.title('My Window')
	window.geometry('800x800')
	
	L1 = tk.Label(text = 'salt table file')
	L1.pack()
	
	tableName = tk.StringVar()
	inputTablesList = os.listdir(os.getcwd().replace("\\code","")+"\\salt_concentrations")

	tableDropdown = tk.OptionMenu(window,tableName,*inputTablesList)
	tableDropdown.pack()


	L2 = tk.Label(text = 'output file name')
	L2.pack()
	e2= tk.Entry()
	e2.pack()

	L3 = tk.Label(text = '\n select organics')
	L3.pack()

	L4 = tk.Label(text = '*Molecule may not be correct as it cannot be perfectly constructed from groups available in AIOMFAC')
	L4.place(x = 150, y= 775)

	b = tk.Button(text = "Run",command = run)
	b.place(x=500,y=25)

	b1= tk.Button(text = "toggle LDR organics",command = checkLDR)
	b1.place(x=200,y=25)

	b2= tk.Button(text = "toggle All organics",command = checkAll)
	b2.place(x=200,y=50)
	

	loc = [None]*len(organicsList)
	check = [None]*len(organicsList)


	colNum = 3
	for i in range(0,len(organicsList)):
		loc[i] = tk.IntVar()
		check[i] = tk.Checkbutton(window, text=organicsList[i][0].splitlines()[1][17:-1],variable=loc[i], onvalue=1, offvalue=0)
		check[i].place(x=(((i%colNum)*250)+50),y=((i//colNum)*25)+125)
	window.mainloop()



def run():
	global e2,loc,check, organicsList,tableName

	array= []

	for i in range(0,len(loc)):
		if (loc[i].get()==1):
			array = array +[i]

	cutOrganicsList = [organicsList[i] for i in array]
	IO(cutOrganicsList,tableName.get(),e2.get())

def checkLDR():
	global e2,loc,check, toggleLDR

	for i in range(0,41):
		loc[i].set(toggleLDR)
	
	toggleLDR = abs(toggleLDR-1)
	
def checkAll():
	global e1,e2,loc,check, toggleLDR, toggleAll

	for i in range(0,len(loc)):
		loc[i].set(toggleAll)
	
	toggleAll = abs(toggleAll-1)


	


getUserInput()
