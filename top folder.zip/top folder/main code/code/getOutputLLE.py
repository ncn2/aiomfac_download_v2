import subprocess
import csv
import os
from numpy import log
def getOutputLLE(header,concArray,directory):

	#if any element of array is 1 it will through an error.
	#this fixes that
	for i in range(0,len(concArray)):
		if(concArray[i] == 1):
			concArray[i] = 0.999999999999

	#gets teh number of chemical species (pre-dissociation)
	numberOfSpecies = len(concArray)
	componentString = ""


	#generates the component string like cp02, cp03 needed for the reference file
	for i in range(2,numberOfSpecies+2):
		if (len(str(i))==1):
			numberString = '0' + str(i)
		else:
			numberString = str(i)
			
		
		componentString = componentString + "cp"+ numberString+','+'\t'

	componentString= componentString[0:-2]
	path = directory + "\\Inputfiles\\input_0404.txt"
	f =open(path,'w')
	f.write(header)
	f.write('\n')
	f.write('point,	T_K,	')
	f.write(componentString)
	f.write('\n')
	f.write('1	    298     ')
	componentString = ""
	for i in range (0,numberOfSpecies):
		componentString = componentString+str(concArray[i])+'\t'

	f.write(componentString[0:-1])
	f.write('\n')
	f.write('====')
	f.write('\n')
	f.close()
	subprocess.call(['wscript.exe',directory+'\\runLLE2.vbs'])

	path = directory+"\\Outputfiles\\AIOMFAC-LLE_output_0404.txt"

	f = open(path,'r')
	k = f.readline()
	k = int(k)
	f.close()
	
	if (k == 2):
		k = 1.0
	else:
		k = -1.0

	
	return k
	
def column(matrix,i):
	return [row[i] for row in matrix]


