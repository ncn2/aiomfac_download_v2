def saltConcConverter(saltArray):
	cationArray = saltArray[0:7]
	anionArray = saltArray[7::]


	cationValenceArray = [1.0]*5+[2.0]*2
	anionValenceArray = [1.0]*7 +[2.0]*2

	for i in range (0,len(cationArray)):
		cationArray[i] = cationArray[i]*cationValenceArray[i]

	for i in range (0,len(anionArray)):
		anionArray[i] = anionArray[i]*anionValenceArray[i]
			

	tempSaltArray=[[0.0]*len(anionArray) for _ in range(len(cationArray))]

	for i in range (0,len(cationArray)):
		for j in range (0,len(anionArray)):
			if(cationArray[i] != 0.0):
				if(anionArray[j] != 0.0):

					if(cationArray[i]<anionArray[j]):
						anionArray[j] = anionArray[j]-cationArray[i]
						tempSaltArray[i][j] = float(tempSaltArray[i][j] + cationArray[i])
						cationArray[i] = 0.0

					else:
						cationArray[i] = cationArray[i]-anionArray[j]
						tempSaltArray[i][j] = float(tempSaltArray[i][j] + anionArray[j])
						anionArray[j] = 0.0


	for i in range (0,len(cationArray)):
		for j in range (0,len(anionArray)):
			if (i>4 or j>7):
				tempSaltArray[i][j] = (tempSaltArray[i][j])/2



	if (sum(anionArray)+sum(cationArray) !=0):
		error = True
	else:
		error = False
		
	toReturn = []
	for j in range(0,7):
		temp = tempSaltArray[j]
		totalMol = sum(temp)+55.55556
		temp = [x/totalMol for x in temp]
                
		toReturn = toReturn+temp

	if not error:
		return toReturn
	else:
		return False
