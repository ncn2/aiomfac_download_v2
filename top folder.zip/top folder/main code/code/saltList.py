headerGenerate = """Input file for AIOMFAC-web model
 
mixture components:
----
component no.:	01
component name:	'Water'
subgroup no., qty:	016, 01
----"""

saltList = [""]*63

saltList[0] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	242,	01
----"""
saltList[1] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	243,	01
----"""
saltList[2] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	244,	01
----"""
saltList[3] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	245,	01
----"""
saltList[4] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	247,	01
----"""
saltList[5] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	248,	01
----"""
saltList[6] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	01
subgroup no., qty:	250,	01
----"""
saltList[7] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	02
subgroup no., qty:	261,	01
----"""
saltList[8] = """component no.:	##
component name:	'inorganic'
subgroup no., qty:	205,	02
subgroup no., qty:	262,	01
----"""
saltList[9] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	242,	01
----"""
saltList[10] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	243,	01
----"""
saltList[11] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	244,	01
----"""
saltList[12] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	245,	01
----"""
saltList[13] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	247,	01
----"""
saltList[14] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	248,	01
----"""
saltList[15] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	01
subgroup no., qty:	250,	01
----"""
saltList[16] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	02
subgroup no., qty:	261,	01
----"""
saltList[17] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	201,	02
subgroup no., qty:	262,	01
----"""
saltList[18] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	242,	01
----"""
saltList[19] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	243,	01
----"""
saltList[20] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	244,	01
----"""
saltList[21] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	245,	01
----"""
saltList[22] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	247,	01
----"""
saltList[23] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	248,	01
----"""
saltList[24] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	01
subgroup no., qty:	250,	01
----"""
saltList[25] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	02
subgroup no., qty:	261,	01
----"""
saltList[26] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	202,	02
subgroup no., qty:	262,	01
----"""
saltList[27] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	242,	01
----"""
saltList[28] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	243,	01
----"""
saltList[29] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	244,	01
----"""
saltList[30] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	245,	01
----"""
saltList[31] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	247,	01
----"""
saltList[32] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	248,	01
----"""
saltList[33] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	01
subgroup no., qty:	250,	01
----"""
saltList[34] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	02
subgroup no., qty:	261,	01
----"""
saltList[35] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	203,	02
subgroup no., qty:	262,	01
----"""
saltList[36] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	242,	01
----"""
saltList[37] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	243,	01
----"""
saltList[38] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	244,	01
----"""
saltList[39] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	245,	01
----"""
saltList[40] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	247,	01
----"""
saltList[41] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	248,	01
----"""
saltList[42] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	01
subgroup no., qty:	250,	01
----"""
saltList[43] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	02
subgroup no., qty:	261,	01
----"""
saltList[44] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	204,	02
subgroup no., qty:	262,	01
----"""
saltList[45] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	242,	02
----"""
saltList[46] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	243,	02
----"""
saltList[47] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	244,	02
----"""
saltList[48] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	245,	02
----"""
saltList[49] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	247,	02
----"""
saltList[50] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	248,	02
----"""
saltList[51] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	250,	02
----"""
saltList[52] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	261,	01
----"""
saltList[53] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	223,	01
subgroup no., qty:	262,	01
----"""
saltList[54] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	242,	02
----"""
saltList[55] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	243,	02
----"""
saltList[56] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	244,	02
----"""
saltList[57] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	245,	02
----"""
saltList[58] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	247,	02
----"""
saltList[59] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	248,	02
----"""
saltList[60] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	250,	02
----"""
saltList[61] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	261,	01
----"""
saltList[62] = """component no.: ##
component name:	'inorganic'
subgroup no., qty:	221,	01
subgroup no., qty:	262,	01
----"""


