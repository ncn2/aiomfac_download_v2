import sys
import os
from getOutputSLE import getOutputSLE
from scipy.optimize import bisect


global variableLoc,headerSave,initialConcSave,directory

def mainSLE(headerInput,concArrayInput):
	global variableLoc,headerSave,initialConcSave, directory

	headerSave = headerInput
	initialConcSave = concArrayInput
	directory= os.getcwd()
	
	#these are called to initialize things so that key variables can be parsed out
	
	





	
	#finds the first concentration of zero in the tank, this is assumed to be the organic
	#that will be varied to get solubility
	variableLoc = findVariable(initialConcSave)
	if(variableLoc == -1):
		#if no concentration to be varied is found, the program quits
		print("EXIT: One organic must be set to concentration of zero")
		sys.exit()

	bnds = [(1e-40,0.1)]
	#results = minimize(fugacityCalculator,[1e-30],method = 'L-BFGS-B',bounds = bnds)
	#results = minimize_scalar(activityCalculator,method ='bounded', bounds = [1e-40,0.01],tol=1e-30)
	transfer = bisect(activityCalculator,0,0.5,maxiter=2000, xtol = 1e-15)

	
	aqueous_array = initialConcSave
	aqueous_array = [1-sum(aqueous_array)]+aqueous_array
	aqueous_array[variableLoc+1] = transfer
	aqueous_frac_array =[x / sum(aqueous_array) for x in aqueous_array]
	molality = aqueous_array[variableLoc+1]/(aqueous_frac_array[0]*0.018)
	return molality


def activityCalculator(transfer):
	global variableLoc,headerSave,initialConcSave,directory
	transfer = transfer
	aqueous_array = initialConcSave
	aqueous_array = [1-sum(aqueous_array)]+aqueous_array
	
	aqueous_array[variableLoc+1] = transfer

	aqueous_frac_array =[x / sum(aqueous_array) for x in aqueous_array]

	
	output = 	getOutputSLE(headerSave,aqueous_frac_array[1::],directory)

	activity = output[variableLoc+1]

	error = output[variableLoc+1] - 1
	return(error)


def findVariable(array):
	for i in range(0,len(array)):
		if(array[i] == 0):
			return i
			break

	return -1


		
