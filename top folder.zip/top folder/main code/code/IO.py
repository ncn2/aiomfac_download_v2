from saltConcConverter import saltConcConverter
from saltList import saltList
import csv
import os
from mainLLE import mainLLE
from mainSLE import mainSLE




def IO(organicsList,tableName,fileName):

	DIR = os.getcwd()
	DIR = DIR.replace("\\code","")
	
	with open(DIR+"\\salt_concentrations\\"+tableName, 'r') as file:
		reader = csv.reader(file)
		tableInput =[]
		
		for row in reader:
			tableInput.append(row)
	tableInput = tableInput[1::]



	


	#pull organic conc
	printHeader = "Tank\Organic,"
	for i in range(0,len(organicsList)):
		solveByMethod =""
		if (organicsList[i][1]== True):
			solveByMethod = "LLE"
		else:
			solveByMethod = "SLE"
		printHeader = printHeader+organicsList[i][0].splitlines()[1][17:-1]+'mol/kgwater by '+solveByMethod+","
	printHeader = printHeader[:-1]

	writeToFile(printHeader,fileName,DIR)


                
	for tableCounter in range(0,len(tableInput)):
		writeToFile("\n",fileName,DIR)
		writeToFile(tableInput[tableCounter][0]+",",fileName,DIR)
		
		for organicCounter in range(0,len(organicsList)):
			if(organicsList[organicCounter][0] != None):
				headerGenerate = ""

				currentRow= tableInput[tableCounter]
				currentOrganic = organicsList[organicCounter]
                                
				saltInput = list(map(float, currentRow[1::]))
				tableName = currentRow[1]
				concArray = saltConcConverter(saltInput)

				headerGenerate = "Input file for AIOMFAC-web model\n \nmixture components:\n----\ncomponent no.:\t01\ncomponent name:\t'Water'\nsubgroup no., qty:\t016, 01\n----" + "\n"+ organicsList[organicCounter][0] + "\n"
				componentCounter = 1;


				finalConcArray = []
				if (concArray != False):
					for j in range(0,len(concArray)):
						if (concArray[j] !=0):
							headerGenerate = headerGenerate +saltList[j].replace('##',('0'+str(componentCounter+2))[-2:]) +"\n"
							componentCounter = componentCounter+1
							finalConcArray = finalConcArray+[concArray[j]]

                                
				headerGenerate = headerGenerate  + "++++" +"\n" + "mixture composition and temperature:" +"\n" +"mass fraction?	0"+"\n"+"mole fraction?	1"+"\n"+"----"

				finalConcArray = [0.0]+finalConcArray
                                
				if(organicsList[organicCounter][1] == True):
					writeToFile(str(mainLLE(headerGenerate,finalConcArray))+",",fileName,DIR)
				if(organicsList[organicCounter][1] == False):
					writeToFile(str(mainSLE(headerGenerate,finalConcArray))+",",fileName,DIR)
			if (concArray == False):
				writeToFile("Solution not neutrally charged,",fileName,DIR)

	writeToFile("\n",fileName,DIR)
	writeToFile("\n",fileName,DIR)
	writeToFile("\n",fileName,DIR)

def writeToFile(text,fileName,DIR):
	fileName = DIR+"\\output_tables\\"+fileName+".txt"
	with open(fileName, 'a') as f:
		f.write(text)
		
