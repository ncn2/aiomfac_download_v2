import sys
import os
from scipy.optimize import bisect
from getOutputLLE import getOutputLLE


global variableLoc,headerSave,initialConcSave,directory

def mainLLE(headerInput,concArrayInput):
	global variableLoc,headerSave,initialConcSave, directory

	headerSave = headerInput
	initialConcSave= concArrayInput
	directory = os.getcwd()
	
	#these are called to initialize things so that key variables can be parsed out

	
		
	#finds the first concentration of zero in the tank, this is assumed to be the organic
	#that will be varied to get solubility
	variableLoc = findVariable(initialConcSave)
	if(variableLoc == -1):
		#if no concentration to be varied is found, the program quits
		return "file failure, one organic concentration must be set to zero"


	upperBound = findSecondPhaseBound()
	if (upperBound == -1):
		return "component is believed to be miscible"

	transfer = bisect(twoPhaseExist,0,upperBound,maxiter = 100)


	aqueous_array = initialConcSave
	aqueous_array = [1-sum(aqueous_array)]+aqueous_array
	aqueous_array[variableLoc+1] = transfer
	aqueous_frac_array =[x / sum(aqueous_array) for x in aqueous_array]
	molality = aqueous_array[variableLoc+1]/(aqueous_frac_array[0]*0.018)


	checkIfAtPhaseBoundary = twoPhaseExist(transfer-0.01)+twoPhaseExist(transfer+0.01)
	if(checkIfAtPhaseBoundary == 0):
		return(str(molality))
	else:
		return(str(molality)+" -may have failed to nconverge on phase boundary")



def twoPhaseExist(transfer):
	global variableLoc,headerSave,initialConcSave,directory
	transfer = transfer
	aqueous_array = initialConcSave
	aqueous_array = [1-sum(aqueous_array)]+aqueous_array
	
	aqueous_array[variableLoc+1] = transfer

	aqueous_frac_array =[x / sum(aqueous_array) for x in aqueous_array]

	
	output = 	getOutputLLE(headerSave,aqueous_frac_array[1::],directory)

	return output


def findVariable(array):
	for i in range(0,len(array)):
		if(array[i] == 0.0):
			return i
			break

	return -1

def findSecondPhaseBound():
	guessArray = [0.1,0.05,0.2,0.01,0.001,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.2,1.3,1.4,0.005,0.15,0.25,0.35,0.45,0.16,0.17]
	for i in range(0,len(guessArray)):
		guessValue = guessArray[i]
		output = twoPhaseExist(guessValue)
		if(output == 1):
			return guessValue

	return -1



		
