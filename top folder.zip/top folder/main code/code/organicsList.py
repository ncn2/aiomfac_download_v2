organicsList = [[None for _ in range(2)] for _ in range(200)]

#if organicsList[x][1] is true, LLE will be used.

organicsList[0][0] = """component no.:	02
component name:	'1-Butanol'
subgroup no., qty:	145,	01
subgroup no., qty:	146,	02
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""
organicsList[0][1] = True

organicsList[1][0] = """component no.:	02
component name:	'methanol'
subgroup no., qty:	149,	01
subgroup no., qty:	153,	01
----"""

organicsList[1][1] = True

organicsList[2][0] ="""component no.:	02
component name:	'1-4-Dioxane'
subgroup no., qty:	002,	02
subgroup no., qty:	025,	02
----"""

organicsList[2][1] = True

organicsList[3][0] ="""component no.:	02
component name:	'cyclohexanone'
subgroup no., qty:	026,	01
subgroup no., qty:	002,	05
----"""

organicsList[3][1] = True

organicsList[4][0] ="""component no.:	02
component name:	'isobutanol'
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
subgroup no., qty:	147,	01
subgroup no., qty:	145,	01
subgroup no., qty:	141,	01
----"""

organicsList[4][1] = True

organicsList[5][0] ="""component no.:	02
component name:	'acrolein'
subgroup no., qty:	020,	01
subgroup no., qty:	005,	01
----"""

organicsList[5][1] = True

organicsList[6][0] ="""component no.:	02
component name:	'Ethyl_acetate'
subgroup no., qty:	001,	01
subgroup no., qty:	002,	01
subgroup no., qty:	021,	01
----"""

organicsList[6][1] = True


organicsList[7][0] ="""component no.:	02
component name:	'methyl methacrylate*'
subgroup no., qty:	021,	01
subgroup no., qty:	001,	01
subgroup no., qty:	007,	01
----"""

organicsList[7][1] = True


organicsList[8][0] ="""component no.:	02
component name:	'ethyl methacrylate*'
subgroup no., qty:	021,	01
subgroup no., qty:	001,	01
subgroup no., qty:	007,	01
subgroup no., qty:	002,	01
----"""

organicsList[8][1] = True


organicsList[9][0] ="""component no.:	02
component name:	'diethyl ether'
subgroup no., qty:	025,	01
subgroup no., qty:	001,	02
subgroup no., qty:	002,	01
----"""

organicsList[9][1] = True


organicsList[10][0] ="""component no.:	02
component name:	'xylenes'
subgroup no., qty:	010,	02
subgroup no., qty:	001,	02
subgroup no., qty:	009,	04
----"""

organicsList[10][1] = True

organicsList[11][0] ="""component no.:	02
component name:	'2-Butanone (MEK)'
subgroup no., qty:	001,	01
subgroup no., qty:	002,	01
subgroup no., qty:	018,	01
----"""

organicsList[11][1] = True

organicsList[12][0] ="""component no.:	02
component name:	'4-Methyl-2-pentanone'
subgroup no., qty:	001,	02
subgroup no., qty:	002,	01
subgroup no., qty:	003,	01
subgroup no., qty:	018,	01
----"""

organicsList[12][1] = True

organicsList[13][0] ="""component no.:	02
component name:	'Acetone'
subgroup no., qty:	001,	01
subgroup no., qty:	018,	01
----"""

organicsList[13][1] = True

organicsList[14][0] ="""component no.:	02
component name:	'Benzene'
subgroup no., qty:	009,	06
----"""

organicsList[14][1] = True

organicsList[15][0] ="""component no.:	02
component name:	'benzyl butyl phthalate*'
subgroup no., qty:	010,	03
subgroup no., qty:	009,	09
subgroup no., qty:	022,	02
subgroup no., qty:	002,	01
subgroup no., qty:	001,	01
----"""

organicsList[15][1] = True

organicsList[16][0] ="""component no.:	02
component name:	'Dibutyl phthalate*'
subgroup no., qty:	009,	04
subgroup no., qty:	010,	02
subgroup no., qty:	022,	02
subgroup no., qty:	002,	04
subgroup no., qty:	001,	02
----"""

organicsList[16][1] = True

organicsList[17][0] ="""component no.:	02
component name:	'diisooctyl phthalate*'
subgroup no., qty:	009,	04
subgroup no., qty:	010,	02
subgroup no., qty:	022,	02
subgroup no., qty:	002,	10
subgroup no., qty:	001,	04
----"""

organicsList[17][1] = True

organicsList[18][0] ="""component no.:	02
component name:	'diethyl phthalate*'
subgroup no., qty:	009,	04
subgroup no., qty:	010,	02
subgroup no., qty:	022,	02
subgroup no., qty:	001,	02
----"""

organicsList[18][1] = True

organicsList[19][0] ="""component no.:	02
component name:	'ethylbenzene'
subgroup no., qty:	010,	01
subgroup no., qty:	002,	01
subgroup no., qty:	001,	01
subgroup no., qty:	009,	05
----"""

organicsList[19][1] = True

organicsList[20][0] ="""component no.:	02
component name:	'toluene'
subgroup no., qty:	010,	01
subgroup no., qty:	001,	01
subgroup no., qty:	009,	05
----"""

organicsList[20][1] = True

organicsList[21][0] ="""component no.:	02
component name:	'acetophenone'
subgroup no., qty:	010,	01
subgroup no., qty:	009,	05
subgroup no., qty:	018,	01
----"""

organicsList[21][1] = True

organicsList[22][0] ="""component no.:	02
component name:	'cresol (all)'
subgroup no., qty:	010,	01
subgroup no., qty:	009,	04
subgroup no., qty:	001,	01
subgroup no., qty:	017,	01
----"""

organicsList[22][1] = True

organicsList[23][0] ="""component no.:	02
component name:	'safrole*'
subgroup no., qty:	010,	03
subgroup no., qty:	009,	03
subgroup no., qty:	005,	01
subgroup no., qty:	002,	01
subgroup no., qty:	025,	02
----"""

organicsList[23][1] = True

organicsList[24][0] ="""component no.:	02
component name:	'isosafrole*'
subgroup no., qty:	010,	03
subgroup no., qty:	009,	03
subgroup no., qty:	006,	01
subgroup no., qty:	025,	02
subgroup no., qty:	001,	01
----"""

organicsList[24][1] = True

organicsList[25][0] ="""component no.:	02
component name:	'Phenol'
subgroup no., qty:	009,	05
subgroup no., qty:	017,	01
----"""

organicsList[25][1] = True

organicsList[26][0] ="""component no.:	02
component name:	'terephthalic acid'
subgroup no., qty:	010,	02
subgroup no., qty:	009,	04
subgroup no., qty:	137,	02
----"""

organicsList[26][1] = False

organicsList[27][0] ="""component no.:	02
component name:	'dibenzopyrenes'
subgroup no., qty:	010,	10
subgroup no., qty:	009,	14
----"""

organicsList[27][1] = False

organicsList[28][0] ="""component no.:	02
component name:	'Benzo(ghi)perylene'
subgroup no., qty:	010,	10
subgroup no., qty:	009,	12
----"""

organicsList[28][1] = False

organicsList[29][0] ="""component no.:	02
component name:	'Methylcholanthrene'
subgroup no., qty:	010,	09
subgroup no., qty:	009,	09
subgroup no., qty:	001,	01
subgroup no., qty:	002,	02
----"""

organicsList[29][1] = False

organicsList[30][0] ="""component no.:	02
component name:	'Acenaphthylene'
subgroup no., qty:	010,	06
subgroup no., qty:	009,	06
subgroup no., qty:	006,	01
----"""

organicsList[30][1] = False

organicsList[31][0] ="""component no.:	02
component name:	'Acenaphthene'
subgroup no., qty:	010,	06
subgroup no., qty:	009,	06
subgroup no., qty:	002,	02
----"""

organicsList[31][1] = False

organicsList[32][0] ="""component no.:	02
component name:	'anthracene'
subgroup no., qty:	010,	04
subgroup no., qty:	009,	10
----"""

organicsList[32][1] = False

organicsList[33][0] ="""component no.:	02
component name:	'Benz(a)anthracene/chrysene'
subgroup no., qty:	010,	06
subgroup no., qty:	009,	12
----"""

organicsList[33][1] = False

organicsList[34][0] ="""component no.:	02
component name:	'Benzo(a)pyrene/Benzofluoranthene'
subgroup no., qty:	010,	08
subgroup no., qty:	009,	12
----"""

organicsList[34][1] = False

organicsList[35][0] ="""component no.:	02
component name:	'Dibenz[a-h]anthracene'
subgroup no., qty:	010,	08
subgroup no., qty:	009,	14
----"""

organicsList[35][1] = False

organicsList[36][0] ="""component no.:	02
component name:	'Fluoranthene'
subgroup no., qty:	010,	06
subgroup no., qty:	009,	10
----"""

organicsList[36][1] = False

organicsList[37][0] ="""component no.:	02
component name:	'flourene'
subgroup no., qty:	010,	04
subgroup no., qty:	009,	08
subgroup no., qty:	002,	01
----"""

organicsList[37][1] = False

organicsList[38][0] ="""component no.:	02
component name:	'Indeno(1-2-3-cd)pyrene'
subgroup no., qty:	010,	10
subgroup no., qty:	009,	12
----"""

organicsList[38][1] = False

organicsList[39][0] ="""component no.:	02
component name:	'napthalene'
subgroup no., qty:	010,	02
subgroup no., qty:	009,	08
----"""

organicsList[39][1] = False

organicsList[40][0] ="""component no.:	02
component name:	'pyrene'
subgroup no., qty:	010,	06
subgroup no., qty:	009,	10
----"""

organicsList[40][1] = False

organicsList[41][0] ="""component no.:	02
component name:	'2-Butanol'
subgroup no., qty:	141,	01
subgroup no., qty:	145,	01
subgroup no., qty:	146,	01
subgroup no., qty:	151,	01
subgroup no., qty:	153,	01
----"""
organicsList[41][1] = True

organicsList[42][0] ="""component no.:	02
component name:	'Isobutanol'
subgroup no., qty:	145,	02
subgroup no., qty:	147,	01
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""

organicsList[42][1] = True
organicsList[43][0] ="""component no.:	02
component name:	'2-Methyl-2-butanol'
subgroup no., qty:	145,	03
subgroup no., qty:	146,	01
subgroup no., qty:	152,	01
subgroup no., qty:	153,	01
----"""
organicsList[43][1] = True

organicsList[44][0] ="""component no.:	02
component name:	'3-Methyl-1-butanol'
subgroup no., qty:	145,	03
subgroup no., qty:	146,	01
subgroup no., qty:	147,	01
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""

organicsList[44][1] = True


organicsList[45][0] ="""component no.:	02
component name:	'2-Methyl-1-butanol'
subgroup no., qty:	145,	02
subgroup no., qty:	146,	02
subgroup no., qty:	151,	01
subgroup no., qty:	153,	01
----"""
organicsList[45][1] = True

organicsList[46][0] ="""component no.:	02
component name:	'1-Pentanol'
subgroup no., qty:	145,	01
subgroup no., qty:	146,	03
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""
organicsList[46][1] = True

organicsList[47][0] ="""component no.:	02
component name:	'2-Pentanol'
subgroup no., qty:	141,	01
subgroup no., qty:	145,	01
subgroup no., qty:	146,	02
subgroup no., qty:	151,	01
subgroup no., qty:	153,	01
----"""

organicsList[47][1] = True

organicsList[48][0] ="""component no.:	02
component name:	'3-Pentanol'
subgroup no., qty:	145,	02
subgroup no., qty:	146,	02
subgroup no., qty:	151,	01
subgroup no., qty:	153,	01
----"""

organicsList[48][1] = True
organicsList[49][0] ="""component no.:	02
component name:	'1-Hexanol'
subgroup no., qty:	145,	01
subgroup no., qty:	146,	04
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""
organicsList[49][1] = True

organicsList[50][0] ="""component no.:	02
component name:	'1-2-Ethanediol'
subgroup no., qty:	150,	02
subgroup no., qty:	153,	02
----"""
organicsList[50][1] = True

organicsList[51][0] ="""component no.:	02
component name:	'1-2-Butanediol'
subgroup no., qty:	145,	01
subgroup no., qty:	146,	01
subgroup no., qty:	150,	01
subgroup no., qty:	151,	01
subgroup no., qty:	153,	02
----"""
organicsList[51][1] = True


organicsList[52][0] ="""component no.:	02
component name:	'Tetrahydrofuran'
subgroup no., qty:	002,	03
subgroup no., qty:	027,	01
----"""
organicsList[52][1] = True

organicsList[53][0] ="""component no.:	02
component name:	'Phenol'
subgroup no., qty:	009,	05
subgroup no., qty:	017,	01
----"""
organicsList[53][1] = True

organicsList[54][0] ="""component no.:	02
component name:	'1-Hexyl_acetate'
subgroup no., qty:	001,	01
subgroup no., qty:	002,	05
subgroup no., qty:	021,	01
----"""
organicsList[54][1] = True

organicsList[55][0] ="""component no.:	02
component name:	'2-Ethoxyethanol'
subgroup no., qty:	001,	01
subgroup no., qty:	002,	01
subgroup no., qty:	025,	01
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""
organicsList[55][1] = True

organicsList[56][0] ="""component no.:	02
component name:	'2-Pentanone'
subgroup no., qty:	001,	01
subgroup no., qty:	002,	02
subgroup no., qty:	018,	01
----"""
organicsList[56][1] = True


organicsList[57][0] ="""component no.:	02
component name:	'2-Butoxyethanol'
subgroup no., qty:	001,	01
subgroup no., qty:	002,	03
subgroup no., qty:	025,	01
subgroup no., qty:	150,	01
subgroup no., qty:	153,	01
----"""
organicsList[57][1] = True

