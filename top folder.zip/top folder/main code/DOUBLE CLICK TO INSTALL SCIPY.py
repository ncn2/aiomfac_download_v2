import pip
pip.main(['install','scipy'])
import scipy
